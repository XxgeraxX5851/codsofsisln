#Codificar una solucion que escriba el siguiente
#texto llenando los espacios en blanco

#Mi nombre es ______ y tengo ____ años de edad.
#Tambien, Siempre he querido ser ________
#Gracias por leer me!

nombre = input("Cual es tu nombre")
edad = input("Que edad tienes")
profesion = input("Que deseas estudiar")

print("Mi nombre es",nombre,"y tengo",edad,"años de edad.")
print("Tambien, Siempre he querido ser",profesion)
print("Gracias por leer me!")
