enero = 31
febrero = 28
marzo = 31
abril = 30 
mayo = 31 
junio = 30  
julio = 31 
agosto = 31 
septiembre = 30
octubre = 31
noviembre = 30 
diciembre = 31 
dia_nac = 7
mes_nac = diciembre
año_nac = 2009

dia_hoy = 10 
mes_hoy = febrero
año_actual = 2025

print(2025-2009)


